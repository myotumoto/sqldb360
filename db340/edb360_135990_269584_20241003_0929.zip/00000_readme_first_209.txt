
Open and read 00001_edb360_<dbname>_index.html

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

initial log:


TOOL_EXEC_HOURS                                                                 
---------------------------------------------------------------------           
Tool Execution Hours so far: ,006                                               


Procedimento PL/SQL conclu�do com sucesso.

DEFINE _DATE           = "03/10/24" (CHAR)
DEFINE _CONNECT_IDENTIFIER = "db340" (CHAR)
DEFINE _USER           = "SYSTEM" (CHAR)
DEFINE _PRIVILEGE      = "" (CHAR)
DEFINE _SQLPLUS_RELEASE = "1903000000" (CHAR)
DEFINE _EDITOR         = "Notepad" (CHAR)
DEFINE _O_VERSION      = "Oracle Database 11g Release 11.2.0.4.0 - 64bit Production" (CHAR)
DEFINE _O_RELEASE      = "1102000400" (CHAR)
DEFINE ASH_VALIDATION  = "" (CHAR)
DEFINE V_DOLLAR        = "V$" (CHAR)
DEFINE MY_SID          = "209" (CHAR)
DEFINE LICENSE_PACK    = "N" (CHAR)
DEFINE DIAGNOSTICS_PACK = "N" (CHAR)
DEFINE SKIP_DIAGNOSTICS = "--" (CHAR)
DEFINE TUNING_PACK     = "N" (CHAR)
DEFINE SKIP_TUNING     = "--" (CHAR)
DEFINE CUSTOM_CONFIG_FILENAME = "null" (CHAR)
DEFINE EDB360_ESTIMATED_HRS = "0" (CHAR)
DEFINE _RC             = "1" (CHAR)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

custom configuration filename: "null"

SP2-0310: n�o foi poss�vel abrir o arquivo "sql/null"
null value passed as 2nd parameter

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

config log:

DEFINE _DATE           = "03/10/24" (CHAR)
DEFINE _CONNECT_IDENTIFIER = "db340" (CHAR)
DEFINE _USER           = "SYSTEM" (CHAR)
DEFINE _PRIVILEGE      = "" (CHAR)
DEFINE _SQLPLUS_RELEASE = "1903000000" (CHAR)
DEFINE _EDITOR         = "Notepad" (CHAR)
DEFINE _O_VERSION      = "Oracle Database 11g Release 11.2.0.4.0 - 64bit Production" (CHAR)
DEFINE _O_RELEASE      = "1102000400" (CHAR)
DEFINE ASH_VALIDATION  = "" (CHAR)
DEFINE V_DOLLAR        = "V$" (CHAR)
DEFINE MY_SID          = "209" (CHAR)
DEFINE LICENSE_PACK    = "N" (CHAR)
DEFINE DIAGNOSTICS_PACK = "N" (CHAR)
DEFINE SKIP_DIAGNOSTICS = "--" (CHAR)
DEFINE TUNING_PACK     = "N" (CHAR)
DEFINE SKIP_TUNING     = "--" (CHAR)
DEFINE CUSTOM_CONFIG_FILENAME = "null" (CHAR)
DEFINE EDB360_ESTIMATED_HRS = "0" (CHAR)
DEFINE _RC             = "1" (CHAR)
DEFINE EDB360_SECTIONS = "" (CHAR)
DEFINE SQL_TRACE_LEVEL = "1" (CHAR)
DEFINE EDB360_CONF_DAYS = "31" (CHAR)
DEFINE EDB360_CONF_DATE_FROM = "YYYY-MM-DD" (CHAR)
DEFINE EDB360_CONF_DATE_TO = "YYYY-MM-DD" (CHAR)
DEFINE EDB360_CONF_WORK_TIME_FROM = "0730" (CHAR)
DEFINE EDB360_CONF_WORK_TIME_TO = "1930" (CHAR)
DEFINE EDB360_CONF_WORK_DAY_FROM = "2" (CHAR)
DEFINE EDB360_CONF_WORK_DAY_TO = "6" (CHAR)
DEFINE EDB360_CONF_MAX_HOURS = "24" (CHAR)
DEFINE EDB360_CHART_WIDTH = "809px" (CHAR)
DEFINE EDB360_CONF_INCL_DBNAME_INDEX = "N" (CHAR)
DEFINE EDB360_CONF_INCL_DBNAME_FILE = "N" (CHAR)
DEFINE EDB360_CONF_INCL_ASH_MEM = "N" (CHAR)
DEFINE EDB360_CONF_INCL_SQL_MON = "N" (CHAR)
DEFINE EDB360_CONF_INCL_STAT_MEM = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_PX_MEM = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_SEGMENTS = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_SOURCE = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_METADATA = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_EADAM = "Y" (CHAR)
DEFINE EDB360_EADAM_ROW_LIMIT = "10000000" (CHAR)
DEFINE TOOL_REPO_USER  = "" (CHAR)
DEFINE EDB360_OUTPUT_DIRECTORY = "" (CHAR)
DEFINE EDB360_MOVE_DIRECTORY = "" (CHAR)
DEFINE SKIP_ESP_AND_ESCP = "" (CHAR)
DEFINE EDB360_CONFIG_DBID = "" (CHAR)
DEFINE EDB360_HOST_NAME_SEPARATOR = "" (CHAR)
DEFINE EDB360_HOST_NAME_POSITION = "" (CHAR)
DEFINE EDB360_HOST_NAME_OCCURRENCE = "" (CHAR)
DEFINE EDB360_CONF_INCL_HTML = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_XML = "N" (CHAR)
DEFINE EDB360_CONF_INCL_TEXT = "N" (CHAR)
DEFINE EDB360_CONF_INCL_CSV = "N" (CHAR)
DEFINE EDB360_CONF_INCL_LINE = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_PIE = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_BAR = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_PERFHUB = "N" (CHAR)
DEFINE EDB360_CONF_INCL_AWR_RPT = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_AWR_DIFF_RPT = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_AWR_RANGE_RPT = "N" (CHAR)
DEFINE EDB360_CONF_INCL_ADDM_RPT = "N" (CHAR)
DEFINE EDB360_CONF_INCL_ASH_RPT = "N" (CHAR)
DEFINE EDB360_CONF_INCL_ASH_ANALY_RPT = "N" (CHAR)
DEFINE EDB360_CONF_INCL_TKPROF = "Y" (CHAR)
DEFINE EDB360_CONF_INCL_PLOT_AWR = "N" (CHAR)
DEFINE EDB360_CONF_SERIES_SELECTION = "N" (CHAR)
DEFINE EDB360_MAX_WORK_DAYS_PEAKS = "3" (CHAR)
DEFINE EDB360_MIN_WORK_DAYS_PEAKS = "1" (CHAR)
DEFINE EDB360_MAX_HISTORY_PEAKS = "3" (CHAR)
DEFINE EDB360_MED_HISTORY = "1" (CHAR)
DEFINE EDB360_MAX_5WD_PEAKS = "3" (CHAR)
DEFINE EDB360_MIN_5WD_PEAKS = "1" (CHAR)
DEFINE EDB360_MAX_7D_PEAKS = "3" (CHAR)
DEFINE EDB360_MED_7D   = "1" (CHAR)
DEFINE EDB360_CONF_TOP_SQL = "16" (CHAR)
DEFINE EDB360_CONF_TOP_CUR = "2" (CHAR)
DEFINE EDB360_CONF_TOP_SIG = "2" (CHAR)
DEFINE EDB360_CONF_PLANX_TOP = "16" (CHAR)
DEFINE EDB360_CONF_SQLMON_TOP = "0" (CHAR)
DEFINE EDB360_CONF_SQLASH_TOP = "0" (CHAR)
DEFINE EDB360_CONF_SQLHC_TOP = "0" (CHAR)
DEFINE EDB360_CONF_SQLD360_TOP = "8" (CHAR)
DEFINE EDB360_CONF_SQLD360_TOP_TC = "0" (CHAR)
DEFINE EDB360_CONF_DD_MODE = "AUTO" (CHAR)
DEFINE EDB360_CONF_CON_OPTION = "A" (CHAR)
DEFINE EDB360_CONF_IS_CDB = "A" (CHAR)
DEFINE TOOL_PREFIX_1   = "dba_hist#" (CHAR)
DEFINE TOOL_PREFIX_2   = "dba#" (CHAR)
DEFINE TOOL_PREFIX_3   = "gv#" (CHAR)
DEFINE TOOL_PREFIX_4   = "v#" (CHAR)
DEFINE EDB360_CONF_TOOL_PAGE = "<a href="http://carlos-sierra.net/edb360-an-oracle-database-360-degree-view/" target="_blank">" (CHAR)
DEFINE EDB360_CONF_ALL_PAGES_ICON = "<a href="http://carlos-sierra.net/edb360-an-oracle-database-360-degree-view/" target="_blank"><img src="database.jpg" alt="eDB360" height="33" width="52" /></a>" (CHAR)
DEFINE EDB360_CONF_ALL_PAGES_LOGO = "" (CHAR)
DEFINE EDB360_CONF_GOOGLE_CHARTS = "<script type="text/javascript" src="https://www.google.com/jsapi"></script>" (CHAR)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

setup log:


Procedimento PL/SQL conclu�do com sucesso.


TOOL_EXEC_HOURS                                                                 
---------------------------------------------------------------------           
Tool Execution Hours so far: 0                                                  

1 linha selecionada.


Procedimento PL/SQL conclu�do com sucesso.


E                                                                               
-                                                                               
                                                                                

1 linha selecionada.


                                                                                
                                                                                

1 linha selecionada.

antigo   2:        decode('&&is_ver_eq_9_1.'    ,'Y','--','N','') skip_ver_eq_9_1,
novo   2:        decode('N'    ,'Y','--','N','') skip_ver_eq_9_1,
antigo   3:        decode('&&is_ver_eq_9_2.'    ,'Y','--','N','') skip_ver_eq_9_2,
novo   3:        decode('N'    ,'Y','--','N','') skip_ver_eq_9_2,
antigo   4:        decode('&&is_ver_eq_9.'      ,'Y','--','N','') skip_ver_eq_9,
novo   4:        decode('N'      ,'Y','--','N','') skip_ver_eq_9,
antigo   5:        decode('&&is_ver_eq_10_1.'   ,'Y','--','N','') skip_ver_eq_10_1,
novo   5:        decode('N'   ,'Y','--','N','') skip_ver_eq_10_1,
antigo   6:        decode('&&is_ver_eq_10_2.'   ,'Y','--','N','') skip_ver_eq_10_2,
novo   6:        decode('N'   ,'Y','--','N','') skip_ver_eq_10_2,
antigo   7:        decode('&&is_ver_eq_10.'     ,'Y','--','N','') skip_ver_eq_10,
novo   7:        decode('N'     ,'Y','--','N','') skip_ver_eq_10,
antigo   8:        decode('&&is_ver_eq_11_1.'   ,'Y','--','N','') skip_ver_eq_11_1,
novo   8:        decode('N'   ,'Y','--','N','') skip_ver_eq_11_1,
antigo   9:        decode('&&is_ver_eq_11_2.'   ,'Y','--','N','') skip_ver_eq_11_2,
novo   9:        decode('Y'   ,'Y','--','N','') skip_ver_eq_11_2,
antigo  10:        decode('&&is_ver_eq_11_201.' ,'Y','--','N','') skip_ver_eq_11_201,
novo  10:        decode('N' ,'Y','--','N','') skip_ver_eq_11_201,
antigo  11:        decode('&&is_ver_eq_11_203.' ,'Y','--','N','') skip_ver_eq_11_203,
novo  11:        decode('N' ,'Y','--','N','') skip_ver_eq_11_203,
antigo  12:        decode('&&is_ver_eq_11.'     ,'Y','--','N','') skip_ver_eq_11,
novo  12:        decode('Y'     ,'Y','--','N','') skip_ver_eq_11,
antigo  13:        decode('&&is_ver_eq_12_101.' ,'Y','--','N','') skip_ver_eq_12_101,
novo  13:        decode('N' ,'Y','--','N','') skip_ver_eq_12_101,
antigo  14:        decode('&&is_ver_eq_12_1.'   ,'Y','--','N','') skip_ver_eq_12_1,
novo  14:        decode('N'   ,'Y','--','N','') skip_ver_eq_12_1,
antigo  15:        decode('&&is_ver_eq_12_2.'   ,'Y','--','N','') skip_ver_eq_12_2,
novo  15:        decode('N'   ,'Y','--','N','') skip_ver_eq_12_2,
antigo  16:        decode('&&is_ver_eq_12.'     ,'Y','--','N','') skip_ver_eq_12,
novo  16:        decode('N'     ,'Y','--','N','') skip_ver_eq_12,
antigo  17:        decode('&&is_ver_eq_18.'     ,'Y','--','N','') skip_ver_eq_18,
novo  17:        decode('N'     ,'Y','--','N','') skip_ver_eq_18,
antigo  18:        decode('&&is_ver_eq_19.'     ,'Y','--','N','') skip_ver_eq_19,
novo  18:        decode('N'     ,'Y','--','N','') skip_ver_eq_19,
antigo  19:        decode('&&is_ver_eq_20.'     ,'Y','--','N','') skip_ver_eq_20,
novo  19:        decode('N'     ,'Y','--','N','') skip_ver_eq_20,
antigo  21:        decode('&&is_ver_le_9_1.'    ,'Y','--','N','') skip_ver_le_9_1,
novo  21:        decode('N'    ,'Y','--','N','') skip_ver_le_9_1,
antigo  22:        decode('&&is_ver_le_9_2.'    ,'Y','--','N','') skip_ver_le_9_2,
novo  22:        decode('N'    ,'Y','--','N','') skip_ver_le_9_2,
antigo  23:        decode('&&is_ver_le_9.'      ,'Y','--','N','') skip_ver_le_9,
novo  23:        decode('N'      ,'Y','--','N','') skip_ver_le_9,
antigo  24:        decode('&&is_ver_le_10_1.'   ,'Y','--','N','') skip_ver_le_10_1,
novo  24:        decode('N'   ,'Y','--','N','') skip_ver_le_10_1,
antigo  25:        decode('&&is_ver_le_10_2.'   ,'Y','--','N','') skip_ver_le_10_2,
novo  25:        decode('N'   ,'Y','--','N','') skip_ver_le_10_2,
antigo  26:        decode('&&is_ver_le_10.'     ,'Y','--','N','') skip_ver_le_10,
novo  26:        decode('N'     ,'Y','--','N','') skip_ver_le_10,
antigo  27:        decode('&&is_ver_le_11_1.'   ,'Y','--','N','') skip_ver_le_11_1,
novo  27:        decode('N'   ,'Y','--','N','') skip_ver_le_11_1,
antigo  28:        decode('&&is_ver_le_11_2.'   ,'Y','--','N','') skip_ver_le_11_2,
novo  28:        decode('Y'   ,'Y','--','N','') skip_ver_le_11_2,
antigo  29: 	   decode('&&is_ver_le_11_201.' ,'Y','--','N','') skip_ver_le_11_201,
novo  29: 	   decode('Y' ,'Y','--','N','') skip_ver_le_11_201,
antigo  30: 	   decode('&&is_ver_le_11_203.' ,'Y','--','N','') skip_ver_le_11_203,
novo  30: 	   decode('Y' ,'Y','--','N','') skip_ver_le_11_203,
antigo  31:        decode('&&is_ver_le_11.'     ,'Y','--','N','') skip_ver_le_11,
novo  31:        decode('Y'     ,'Y','--','N','') skip_ver_le_11,
antigo  32:        decode('&&is_ver_le_12_1.'   ,'Y','--','N','') skip_ver_le_12_1,
novo  32:        decode('Y'   ,'Y','--','N','') skip_ver_le_12_1,
antigo  33:        decode('&&is_ver_le_12_101.' ,'Y','--','N','') skip_ver_le_12_101,
novo  33:        decode('Y' ,'Y','--','N','') skip_ver_le_12_101,
antigo  34:        decode('&&is_ver_le_12_2.'   ,'Y','--','N','') skip_ver_le_12_2,
novo  34:        decode('Y'   ,'Y','--','N','') skip_ver_le_12_2,
antigo  35:        decode('&&is_ver_le_12.'     ,'Y','--','N','') skip_ver_le_12,
novo  35:        decode('Y'     ,'Y','--','N','') skip_ver_le_12,
antigo  36:        decode('&&is_ver_le_18.'     ,'Y','--','N','') skip_ver_le_18,
novo  36:        decode('Y'     ,'Y','--','N','') skip_ver_le_18,
antigo  37:        decode('&&is_ver_le_19.'     ,'Y','--','N','') skip_ver_le_19,
novo  37:        decode('Y'     ,'Y','--','N','') skip_ver_le_19,
antigo  38:        decode('&&is_ver_le_20.'     ,'Y','--','N','') skip_ver_le_20,
novo  38:        decode('Y'     ,'Y','--','N','') skip_ver_le_20,
antigo  40:        decode('&&is_ver_ge_9_1.'    ,'Y','--','N','') skip_ver_ge_9_1,
novo  40:        decode('Y'    ,'Y','--','N','') skip_ver_ge_9_1,
antigo  41:        decode('&&is_ver_ge_9_2.'    ,'Y','--','N','') skip_ver_ge_9_2,
novo  41:        decode('Y'    ,'Y','--','N','') skip_ver_ge_9_2,
antigo  42:        decode('&&is_ver_ge_9.'      ,'Y','--','N','') skip_ver_ge_9,
novo  42:        decode('Y'      ,'Y','--','N','') skip_ver_ge_9,
antigo  43:        decode('&&is_ver_ge_10_1.'   ,'Y','--','N','') skip_ver_ge_10_1,
novo  43:        decode('Y'   ,'Y','--','N','') skip_ver_ge_10_1,
antigo  44:        decode('&&is_ver_ge_10_2.'   ,'Y','--','N','') skip_ver_ge_10_2,
novo  44:        decode('Y'   ,'Y','--','N','') skip_ver_ge_10_2,
antigo  45:        decode('&&is_ver_ge_10.'     ,'Y','--','N','') skip_ver_ge_10,
novo  45:        decode('Y'     ,'Y','--','N','') skip_ver_ge_10,
antigo  46:        decode('&&is_ver_ge_11_1.'   ,'Y','--','N','') skip_ver_ge_11_1,
novo  46:        decode('Y'   ,'Y','--','N','') skip_ver_ge_11_1,
antigo  47:        decode('&&is_ver_ge_11_2.'   ,'Y','--','N','') skip_ver_ge_11_2,
novo  47:        decode('Y'   ,'Y','--','N','') skip_ver_ge_11_2,
antigo  48:        decode('&&is_ver_ge_11.'     ,'Y','--','N','') skip_ver_ge_11,
novo  48:        decode('Y'     ,'Y','--','N','') skip_ver_ge_11,
antigo  49:        decode('&&is_ver_ge_12_1.'   ,'Y','--','N','') skip_ver_ge_12_1,
novo  49:        decode('N'   ,'Y','--','N','') skip_ver_ge_12_1,
antigo  50:        decode('&&is_ver_ge_12_2.'   ,'Y','--','N','') skip_ver_ge_12_2,
novo  50:        decode('N'   ,'Y','--','N','') skip_ver_ge_12_2,
antigo  51:        decode('&&is_ver_ge_12.'     ,'Y','--','N','') skip_ver_ge_12,
novo  51:        decode('N'     ,'Y','--','N','') skip_ver_ge_12,
antigo  52:        decode('&&is_ver_ge_18.'     ,'Y','--','N','') skip_ver_ge_18,
novo  52:        decode('N'     ,'Y','--','N','') skip_ver_ge_18,
antigo  53:        decode('&&is_ver_ge_19.'     ,'Y','--','N','') skip_ver_ge_19,
novo  53:        decode('N'     ,'Y','--','N','') skip_ver_ge_19,
antigo  54:        decode('&&is_ver_ge_20.'     ,'Y','--','N','') skip_ver_ge_20
novo  54:        decode('N'     ,'Y','--','N','') skip_ver_ge_20

                                                                                
                                                                                

1 linha selecionada.

antigo   1: select DECODE('&&is_ver_ge_12.','Y','CDB','''N''') is_cdb_temp_col from dual
novo   1: select DECODE('N','Y','CDB','''N''') is_cdb_temp_col from dual

                                                                                
                                                                                

1 linha selecionada.

antigo   1: select substr(&&is_cdb_temp_col.,1,1) is_cdb from v$database
novo   1: select substr('N',1,1) is_cdb from v$database

                                                                                
                                                                                

1 linha selecionada.

antigo   2: decode('&&is_cdb.','Y','','N','--') skip_noncdb,
novo   2: decode('N','Y','','N','--') skip_noncdb,
antigo   3: decode('&&is_cdb.','Y','--','N','') skip_cdb
novo   3: decode('N','Y','--','N','') skip_cdb

                                                                                
                                                                                

1 linha selecionada.

fetch first row only
      *
ERRO na linha 6:
ORA-00933: comando SQL n�o encerrado adequadamente 


antigo   1: SELECT DECODE(UPPER('&&env_conf_is_cdb'),'Y','Y','N','N','&&env_is_cdb.') env_is_cdb
novo   1: SELECT DECODE(UPPER('A'),'Y','Y','N','N','N') env_is_cdb

E                                                                               
-                                                                               
N                                                                               

1 linha selecionada.

antigo   2:  (CASE WHEN upper('&&env_conf_dd_mode.')  IN ('DBA_HIST','CDB_HIST','AWR_ROOT','AWR_CDB','AWR_PDB')
novo   2:  (CASE WHEN upper('AUTO')  IN ('DBA_HIST','CDB_HIST','AWR_ROOT','AWR_CDB','AWR_PDB')
antigo   3:        THEN upper('&&env_conf_dd_mode.')
novo   3:        THEN upper('AUTO')
antigo   5:    (CASE '&&env_pdb_name.'
novo   5:    (CASE 'NONE'
antigo  11:  ,decode(upper('&&env_conf_con_option.'),'Y','CON_','') env_awr_con_option
novo  11:  ,decode(upper('A'),'Y','CON_','') env_awr_con_option

ENV_DD_M E                                                                      
-------- -                                                                      
DBA_HIST                                                                        

1 linha selecionada.

antigo   4:  WHERE '&&env_dd_mode'='AWR_ROOT'
novo   4:  WHERE 'DBA_HIST'='AWR_ROOT'
antigo   5:    and '&&env_diagnostics_pack.' = 'Y'
novo   5:    and 'N' = 'Y'
fetch first row only
*
ERRO na linha 6:
ORA-00933: comando SQL n�o encerrado adequadamente 


antigo   3:  WHERE NOT EXISTS (SELECT 1 FROM dba_catalog where table_name='&&env_dd_mode._SNAPSHOT')
novo   3:  WHERE NOT EXISTS (SELECT 1 FROM dba_catalog where table_name='DBA_HIST_SNAPSHOT')

n�o h� linhas selecionadas

antigo   5:   and '&&env_diagnostics_pack.' = 'Y'
novo   5:   and 'N' = 'Y'
antigo   6:   and '&&env_pdb_name.'<>'CDB$ROOT'
novo   6:   and 'NONE'<>'CDB$ROOT'
antigo   7:   and upper('&&env_conf_con_option.') not in ('Y','N')
novo   7:   and upper('A') not in ('Y','N')
fetch first row only
*
ERRO na linha 8:
ORA-00933: comando SQL n�o encerrado adequadamente 


antigo   2: decode('&&env_is_cdb.','Y','','N','--') skip_noncdb,
novo   2: decode('N','Y','','N','--') skip_noncdb,
antigo   3: decode('&&env_is_cdb.','Y','--','N','') skip_cdb
novo   3: decode('N','Y','--','N','') skip_cdb

                                                                                
                                                                                

1 linha selecionada.

antigo   3: FROM DUAL WHERE '&&env_dd_mode.'='DBA_HIST'
novo   3: FROM DUAL WHERE 'DBA_HIST'='DBA_HIST'
antigo   7: FROM DUAL WHERE '&&env_dd_mode.'='CDB_HIST'
novo   7: FROM DUAL WHERE 'DBA_HIST'='CDB_HIST'
antigo  11: FROM DUAL WHERE '&&env_dd_mode.'='AWR_ROOT'
novo  11: FROM DUAL WHERE 'DBA_HIST'='AWR_ROOT'
antigo  15: FROM DUAL WHERE '&&env_dd_mode.'='AWR_CDB'
novo  15: FROM DUAL WHERE 'DBA_HIST'='AWR_CDB'
antigo  19: FROM DUAL WHERE '&&env_dd_mode.'='AWR_PDB'
novo  19: FROM DUAL WHERE 'DBA_HIST'='AWR_PDB'

ENV_AWR_H ENV_AWR_O                                                             
--------- ---------                                                             
DBA_HIST_ dba_                                                                  

1 linha selecionada.

antigo   1: SELECT TRIM(TO_CHAR(NVL(TO_NUMBER('&&env_conf_dbid.'), dbid))) env_dbid FROM v$database
novo   1: SELECT TRIM(TO_CHAR(NVL(TO_NUMBER(''), dbid))) env_dbid FROM v$database

ENV_DBID                                                                        
----------------------------------------                                        
604135990                                                                       

1 linha selecionada.

antigo   2:      TRIM(TO_CHAR(NVL(TO_NUMBER('&&env_conf_dbid.'), v.con_dbid))) env_dbid
novo   2:      TRIM(TO_CHAR(NVL(TO_NUMBER(''), v.con_dbid))) env_dbid
antigo   3: FROM v$database v, &&env_awr_hist_prefix.snapshot s
novo   3: FROM v$database v, DBA_HIST_snapshot s
antigo   5:   AND '&&env_is_cdb.'='Y'
novo   5:   AND 'N'='Y'
antigo   6:   and '&&env_diagnostics_pack.' = 'Y'
novo   6:   and 'N' = 'Y'
fetch first row only
*
ERRO na linha 7:
ORA-00933: comando SQL n�o encerrado adequadamente 


antigo   1: SELECT NVL(TO_CHAR(LEAST(CEIL(SYSDATE - CAST(MIN(begin_interval_time) AS DATE)), GREATEST(31, TO_NUMBER(NVL(TRIM('&&env_conf_days.'), '31'))))),'31') env_history_days
novo   1: SELECT NVL(TO_CHAR(LEAST(CEIL(SYSDATE - CAST(MIN(begin_interval_time) AS DATE)), GREATEST(31, TO_NUMBER(NVL(TRIM('31'), '31'))))),'31') env_history_days
antigo   2:   FROM &&env_awr_hist_prefix.snapshot
novo   2:   FROM DBA_HIST_snapshot
antigo   3:  WHERE '&&env_diagnostics_pack.' = 'Y'
novo   3:  WHERE 'N' = 'Y'
antigo   4:    AND '&&env_conf_date_from.' = 'YYYY-MM-DD' AND '&&env_conf_date_to.' = 'YYYY-MM-DD'
novo   4:    AND 'YYYY-MM-DD' = 'YYYY-MM-DD' AND 'YYYY-MM-DD' = 'YYYY-MM-DD'
antigo   5:    AND dbid = &&env_dbid.
novo   5:    AND dbid = 604135990

ENV_HISTORY_DAYS                                                                
----------------------------------------                                        
31                                                                              

1 linha selecionada.

antigo   1: SELECT TO_CHAR(TO_DATE('&&env_conf_date_to.', 'YYYY-MM-DD') - TO_DATE('&&env_conf_date_from.', 'YYYY-MM-DD') + 1) env_history_days
novo   1: SELECT TO_CHAR(TO_DATE('YYYY-MM-DD', 'YYYY-MM-DD') - TO_DATE('YYYY-MM-DD', 'YYYY-MM-DD') + 1) env_history_days
antigo   3:  WHERE '&&env_conf_date_from.' != 'YYYY-MM-DD' AND '&&env_conf_date_to.' != 'YYYY-MM-DD'
novo   3:  WHERE 'YYYY-MM-DD' != 'YYYY-MM-DD' AND 'YYYY-MM-DD' != 'YYYY-MM-DD'

n�o h� linhas selecionadas

antigo   1: SELECT CASE '&&env_conf_date_from.' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE - &&env_history_days., '&&env_date_format.') ELSE '&&env_conf_date_from.T00:00:00' END env_date_from
novo   1: SELECT CASE 'YYYY-MM-DD' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE - 31, 'YYYY-MM-DD"T"HH24:MI:SS') ELSE 'YYYY-MM-DDT00:00:00' END env_date_from
antigo   2:       ,CASE '&&env_conf_date_to.' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE, '&&env_date_format.') ELSE '&&env_conf_date_to.T23:59:59' END env_date_to
novo   2:       ,CASE 'YYYY-MM-DD' WHEN 'YYYY-MM-DD' THEN TO_CHAR(SYSDATE, 'YYYY-MM-DD"T"HH24:MI:SS') ELSE 'YYYY-MM-DDT23:59:59' END env_date_to

ENV_DATE_FROM       ENV_DATE_TO                                                 
------------------- -------------------                                         
2024-09-02T09:29:23 2024-10-03T09:29:23                                         

1 linha selecionada.

antigo   2:       ,NVL(TO_CHAR(MAX(end_interval_time),'&&env_date_format.'),'&&env_date_to.') env_date_to
novo   2:       ,NVL(TO_CHAR(MAX(end_interval_time),'YYYY-MM-DD"T"HH24:MI:SS'),'2024-10-03T09:29:23') env_date_to
antigo   3:   FROM &&env_awr_hist_prefix.snapshot
novo   3:   FROM DBA_HIST_snapshot
antigo   4:  WHERE '&&env_diagnostics_pack.' = 'Y'
novo   4:  WHERE 'N' = 'Y'
antigo   5:    AND dbid = &&env_dbid.
novo   5:    AND dbid = 604135990
antigo   6:    AND end_interval_time <= TO_DATE('&&env_date_to.', '&&env_date_format.')
novo   6:    AND end_interval_time <= TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS')

ENV_MAXIMUM_SNAP_ID                      ENV_DATE_TO                            
---------------------------------------- -------------------                    
1                                        2024-10-03T09:29:23                    

1 linha selecionada.

antigo   1: SELECT '-1' env_maximum_snap_id FROM DUAL WHERE TRIM('&&env_maximum_snap_id.') IS NULL
novo   1: SELECT '-1' env_maximum_snap_id FROM DUAL WHERE TRIM('1') IS NULL

n�o h� linhas selecionadas

antigo   2:       ,NVL(TO_CHAR(MIN(begin_interval_time),'&&env_date_format.'),'&&env_date_from.') env_date_from
novo   2:       ,NVL(TO_CHAR(MIN(begin_interval_time),'YYYY-MM-DD"T"HH24:MI:SS'),'2024-09-02T09:29:23') env_date_from
antigo   3:   FROM &&env_awr_hist_prefix.snapshot
novo   3:   FROM DBA_HIST_snapshot
antigo   4:  WHERE '&&env_diagnostics_pack.' = 'Y'
novo   4:  WHERE 'N' = 'Y'
antigo   5:    AND dbid = &&env_dbid.
novo   5:    AND dbid = 604135990
antigo   6:    AND begin_interval_time >=TO_DATE('&&env_date_to.', '&&env_date_format.')-&&env_history_days.
novo   6:    AND begin_interval_time >=TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS')-31
antigo   7:    AND begin_interval_time < TO_DATE('&&env_date_to.', '&&env_date_format.')
novo   7:    AND begin_interval_time < TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS')

ENV_MINIMUM_SNAP_ID                      ENV_DATE_FROM                          
---------------------------------------- -------------------                    
0                                        2024-09-02T09:29:23                    

1 linha selecionada.

antigo   1: SELECT '-1' env_minimum_snap_id FROM DUAL WHERE TRIM('&&env_minimum_snap_id.') IS NULL
novo   1: SELECT '-1' env_minimum_snap_id FROM DUAL WHERE TRIM('0') IS NULL

n�o h� linhas selecionadas

antigo   1: SELECT TO_CHAR(TRIM(GREATEST(ROUND(TO_DATE('&&env_date_to.', '&&env_date_format.') - TO_DATE('&&env_date_from.', '&&env_date_format.')),1))) env_history_days
novo   1: SELECT TO_CHAR(TRIM(GREATEST(ROUND(TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS') - TO_DATE('2024-09-02T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS')),1))) env_history_days

EN                                                                              
--                                                                              
31                                                                              

1 linha selecionada.

antigo   1: SELECT CASE WHEN '&&tool_repo_user.' IS NULL THEN '&&awr_object_prefix.' ELSE '&&tool_repo_user..&&tool_prefix_1.' END awr_object_prefix,
novo   1: SELECT CASE WHEN '' IS NULL THEN 'dba_' ELSE '.dba_hist#' END awr_object_prefix,
antigo   2:        CASE WHEN '&&tool_repo_user.' IS NULL THEN '&&dva_object_prefix.' ELSE '&&tool_repo_user..&&tool_prefix_2.' END dva_object_prefix,
novo   2:        CASE WHEN '' IS NULL THEN 'dba_' ELSE '.dba#' END dva_object_prefix,
antigo   3:        CASE WHEN '&&tool_repo_user.' IS NULL THEN '&&gv_object_prefix.'  ELSE '&&tool_repo_user..&&tool_prefix_3.' END gv_object_prefix,
novo   3:        CASE WHEN '' IS NULL THEN 'gv$'  ELSE '.gv#' END gv_object_prefix,
antigo   4:        CASE WHEN '&&tool_repo_user.' IS NULL THEN '&&v_object_prefix.'   ELSE '&&tool_repo_user..&&tool_prefix_4.' END v_object_prefix
novo   4:        CASE WHEN '' IS NULL THEN 'v$'   ELSE '.v#' END v_object_prefix

AWR_OBJECT DVA_O GV_O V_O                                                       
---------- ----- ---- ---                                                       
dba_       dba_  gv$  v$                                                        

1 linha selecionada.

antigo   1: SELECT CASE WHEN '&&is_cdb' = 'Y' THEN 'CDB_'      ELSE '&&dva_view_prefix'   END cdb_view_prefix
novo   1: SELECT CASE WHEN 'N' = 'Y' THEN 'CDB_'      ELSE 'DBA_'   END cdb_view_prefix
antigo   2: ,      CASE WHEN '&&is_cdb' = 'Y' THEN 'cdb_'      ELSE '&&dva_object_prefix' END cdb_object_prefix
novo   2: ,      CASE WHEN 'N' = 'Y' THEN 'cdb_'      ELSE 'dba_' END cdb_object_prefix

CDB_ CDB_                                                                       
---- ----                                                                       
DBA_ dba_                                                                       

1 linha selecionada.

antigo   1: SELECT '&&cdb_awr_hist_prefix.&&cdb_awr_con_option.sysmetric_hist' edb360_sysmetric_history
novo   1: SELECT 'DBA_HIST_sysmetric_hist' edb360_sysmetric_history
antigo   2:       ,'&&cdb_awr_hist_prefix.&&cdb_awr_con_option.sysmetric_summ' edb360_sysmetric_summary
novo   2:       ,'DBA_HIST_sysmetric_summ' edb360_sysmetric_summary
antigo   4:   FROM DUAL WHERE '&&cdb_awr_con_option.' IS NOT NULL
novo   4:   FROM DUAL WHERE '' IS NOT NULL
antigo   6: SELECT '&&cdb_awr_hist_prefix.sysmetric_history' edb360_sysmetric_history
novo   6: SELECT 'DBA_HIST_sysmetric_history' edb360_sysmetric_history
antigo   7:       ,'&&cdb_awr_hist_prefix.sysmetric_summary' edb360_sysmetric_summary
novo   7:       ,'DBA_HIST_sysmetric_summary' edb360_sysmetric_summary
antigo   9:   FROM DUAL WHERE '&&cdb_awr_con_option.' IS NULL
novo   9:   FROM DUAL WHERE '' IS NULL

EDB360_SYSMETRIC_HISTORY   EDB360_SYSMETRIC_SUMMARY   EDB360_SYSMETRIC_GROUP    
-------------------------- -------------------------- ----------------------    
DBA_HIST_sysmetric_history DBA_HIST_sysmetric_summary                      2    

1 linha selecionada.

antigo   1: SELECT TO_CHAR(NVL(TO_DATE('&&edb360_date_to.', '&&edb360_date_format.'),SYSDATE), 'YYYYMMDDHH24MISS') tool_sysdate FROM DUAL
novo   1: SELECT TO_CHAR(NVL(TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS'),SYSDATE), 'YYYYMMDDHH24MISS') tool_sysdate FROM DUAL

TOOL_SYSDATE                                                                    
--------------                                                                  
20241003092923                                                                  

1 linha selecionada.

antigo   1: SELECT ', between &&edb360_date_from. and &&edb360_date_to.' between_dates FROM DUAL
novo   1: SELECT ', between 2024-09-02T09:29:23 and 2024-10-03T09:29:23' between_dates FROM DUAL

BETWEEN_DATES                                                                   
-----------------------------------------------------                           
, between 2024-09-02T09:29:23 and 2024-10-03T09:29:23                           

1 linha selecionada.

antigo   2:   :hist_days := ROUND(TO_DATE('&&edb360_date_to.', '&&edb360_date_format.') - TO_DATE('&&edb360_date_from.', '&&edb360_date_format.'));
novo   2:   :hist_days := ROUND(TO_DATE('2024-10-03T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS') - TO_DATE('2024-09-02T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS'));
antigo   6:     IF TO_CHAR(TO_DATE('&&edb360_date_from.', '&&edb360_date_format.') + i, 'D') BETWEEN TO_NUMBER('&&edb360_conf_work_day_from.') AND TO_NUMBER('&&edb360_conf_work_day_to.') THEN
novo   6:     IF TO_CHAR(TO_DATE('2024-09-02T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS') + i, 'D') BETWEEN TO_NUMBER('2') AND TO_NUMBER('6') THEN
antigo   8:       dbms_output.put_line((TO_DATE('&&edb360_date_from.', '&&edb360_date_format.') + i)||' '||:hist_work_days);
novo   8:       dbms_output.put_line((TO_DATE('2024-09-02T09:29:23', 'YYYY-MM-DD"T"HH24:MI:SS') + i)||' '||:hist_work_days);

Procedimento PL/SQL conclu�do com sucesso.


HIST_WORK_DAYS                                                                  
--------------                                                                  
            23                                                                  


 HIST_DAYS                                                                      
----------                                                                      
        31                                                                      


HIST_WORK_DAYS                                                                  
----------------------------------------                                        
23                                                                              

1 linha selecionada.


antigo   2:   IF '&&edb360_sections.' IS NULL THEN -- no sections were selected as per config parameter on edb360_00_config.sql or custom file passed
novo   2:   IF '' IS NULL THEN -- no sections were selected as per config parameter on edb360_00_config.sql or custom file passed
antigo   3:     IF LOWER(NVL(TRIM('&&custom_config_filename.'), 'null')) = 'null' THEN -- 2nd execution parameter is null
novo   3:     IF LOWER(NVL(TRIM('null'), 'null')) = 'null' THEN -- 2nd execution parameter is null
antigo   5:     ELSIF LENGTH(TRIM('&&custom_config_filename.')) <= 5 AND TRIM('&&custom_config_filename.') BETWEEN '1' AND '9' AND INSTR('&&custom_config_filename.',',') = 0 THEN -- assume 2nd execution parameter is a section selection
novo   5:     ELSIF LENGTH(TRIM('null')) <= 5 AND TRIM('null') BETWEEN '1' AND '9' AND INSTR('null',',') = 0 THEN -- assume 2nd execution parameter is a section selection
antigo   6:       :edb360_sections := LOWER(TRIM('&&custom_config_filename.')); -- second parameter becomes potential sections selection
novo   6:       :edb360_sections := LOWER(TRIM('null')); -- second parameter becomes potential sections selection
antigo   7:     ELSIF INSTR('&&custom_config_filename.',',') > 0 THEN -- assume 2nd execution parameter is a section list
novo   7:     ELSIF INSTR('null',',') > 0 THEN -- assume 2nd execution parameter is a section list
antigo   8:       :edb360_sections := ','||LOWER(TRIM('&&custom_config_filename.'))||','; -- second parameter becomes potential section list
novo   8:       :edb360_sections := ','||LOWER(TRIM('null'))||','; -- second parameter becomes potential section list
antigo  13:     :edb360_sections := LOWER(TRIM('&&edb360_sections.'));
novo  13:     :edb360_sections := LOWER(TRIM(''));

Procedimento PL/SQL conclu�do com sucesso.

edb360_sec_from edb360_sec_to edb360_sections

EDB360_SEC_FROM                                                                 
--------------------------------                                                
1a                                                                              


EDB360_SEC_TO                                                                   
--------------------------------                                                
9z                                                                              


EDB360_SECTIONS                                                                 
--------------------------------------------------------------------------------
                                                                                



SKIP_EXTRAS                                                                     
-----------                                                                     
                                                                                

1 linha selecionada.


antigo   1: SELECT CASE '&&edb360_conf_incl_tkprof.' WHEN 'Y'                                       THEN 'edb360_0g_' ELSE ' echo skip ' END edb360_0g FROM DUAL
novo   1: SELECT CASE 'Y' WHEN 'Y'                                       THEN 'edb360_0g_' ELSE ' echo skip ' END edb360_0g FROM DUAL

EDB360_0G                                                                       
----------                                                                      
edb360_0g_                                                                      

1 linha selecionada.


EDB360_1A                                                                       
-----------                                                                     
edb360_1a_                                                                      

1 linha selecionada.


EDB360_1B                                                                       
-----------                                                                     
edb360_1b_                                                                      

1 linha selecionada.


EDB360_1C                                                                       
-----------                                                                     
edb360_1c_                                                                      

1 linha selecionada.


EDB360_1D                                                                       
-----------                                                                     
edb360_1d_                                                                      

1 linha selecionada.


EDB360_1E                                                                       
-----------                                                                     
edb360_1e_                                                                      

1 linha selecionada.


EDB360_1F                                                                       
-----------                                                                     
edb360_1f_                                                                      

1 linha selecionada.


EDB360_1G                                                                       
-----------                                                                     
edb360_1g_                                                                      

1 linha selecionada.


EDB360_2A                                                                       
-----------                                                                     
edb360_2a_                                                                      

1 linha selecionada.


EDB360_2B                                                                       
-----------                                                                     
edb360_2b_                                                                      

1 linha selecionada.


EDB360_2C                                                                       
-----------                                                                     
edb360_2c_                                                                      

1 linha selecionada.


EDB360_2D                                                                       
-----------                                                                     
edb360_2d_                                                                      

1 linha selecionada.


EDB360_2E                                                                       
-----------                                                                     
edb360_2e_                                                                      

1 linha selecionada.


EDB360_3A                                                                       
-----------                                                                     
edb360_3a_                                                                      

1 linha selecionada.


EDB360_3B                                                                       
-----------                                                                     
edb360_3b_                                                                      

1 linha selecionada.


EDB360_3C                                                                       
-----------                                                                     
edb360_3c_                                                                      

1 linha selecionada.


EDB360_3D                                                                       
-----------                                                                     
edb360_3d_                                                                      

1 linha selecionada.


EDB360_3E                                                                       
-----------                                                                     
edb360_3e_                                                                      

1 linha selecionada.


EDB360_3F                                                                       
-----------                                                                     
edb360_3f_                                                                      

1 linha selecionada.


EDB360_3G                                                                       
-----------                                                                     
edb360_3g_                                                                      

1 linha selecionada.


EDB360_3H                                                                       
-----------                                                                     
edb360_3h_                                                                      

1 linha selecionada.


EDB360_3I                                                                       
-----------                                                                     
edb360_3i_                                                                      

1 linha selecionada.


EDB360_3J                                                                       
-----------                                                                     
edb360_3j_                                                                      

1 linha selecionada.


EDB360_4A                                                                       
-----------                                                                     
edb360_4a_                                                                      

1 linha selecionada.


EDB360_4B                                                                       
-----------                                                                     
edb360_4b_                                                                      

1 linha selecionada.


EDB360_4C                                                                       
-----------                                                                     
edb360_4c_                                                                      

1 linha selecionada.


EDB360_4D                                                                       
-----------                                                                     
edb360_4d_                                                                      

1 linha selecionada.


EDB360_4E                                                                       
-----------                                                                     
edb360_4e_                                                                      

1 linha selecionada.


EDB360_4F                                                                       
-----------                                                                     
edb360_4f_                                                                      

1 linha selecionada.


EDB360_4G                                                                       
-----------                                                                     
edb360_4g_                                                                      

1 linha selecionada.


EDB360_4H                                                                       
-----------                                                                     
edb360_4h_                                                                      

1 linha selecionada.


EDB360_4I                                                                       
-----------                                                                     
edb360_4i_                                                                      

1 linha selecionada.


EDB360_4J                                                                       
-----------                                                                     
edb360_4j_                                                                      

1 linha selecionada.


EDB360_4K                                                                       
-----------                                                                     
edb360_4k_                                                                      

1 linha selecionada.


EDB360_4L                                                                       
-----------                                                                     
edb360_4l_                                                                      

1 linha selecionada.


EDB360_5A                                                                       
-----------                                                                     
edb360_5a_                                                                      

1 linha selecionada.


EDB360_5B                                                                       
-----------                                                                     
edb360_5b_                                                                      

1 linha selecionada.


EDB360_5C                                                                       
-----------                                                                     
edb360_5c_                                                                      

1 linha selecionada.


EDB360_5D                                                                       
-----------                                                                     
edb360_5d_                                                                      

1 linha selecionada.


EDB360_5E                                                                       
-----------                                                                     
edb360_5e_                                                                      

1 linha selecionada.


EDB360_5F                                                                       
-----------                                                                     
edb360_5f_                                                                      

1 linha selecionada.


EDB360_5G                                                                       
-----------                                                                     
edb360_5g_                                                                      

1 linha selecionada.


EDB360_6A                                                                       
-----------                                                                     
edb360_6a_                                                                      

1 linha selecionada.


EDB360_6B                                                                       
-----------                                                                     
edb360_6b_                                                                      

1 linha selecionada.


EDB360_6C                                                                       
-----------                                                                     
edb360_6c_                                                                      

1 linha selecionada.


EDB360_6D                                                                       
-----------                                                                     
edb360_6d_                                                                      

1 linha selecionada.


EDB360_6E                                                                       
-----------                                                                     
edb360_6e_                                                                      

1 linha selecionada.


EDB360_6F                                                                       
-----------                                                                     
edb360_6f_                                                                      

1 linha selecionada.


EDB360_6G                                                                       
-----------                                                                     
edb360_6g_                                                                      

1 linha selecionada.


EDB360_6H                                                                       
-----------                                                                     
edb360_6h_                                                                      

1 linha selecionada.


EDB360_6I                                                                       
-----------                                                                     
edb360_6i_                                                                      

1 linha selecionada.


EDB360_6J                                                                       
-----------                                                                     
edb360_6j_                                                                      

1 linha selecionada.


EDB360_6K                                                                       
-----------                                                                     
edb360_6k_                                                                      

1 linha selecionada.


EDB360_6L                                                                       
-----------                                                                     
edb360_6l_                                                                      

1 linha selecionada.


EDB360_6M                                                                       
-----------                                                                     
edb360_6m_                                                                      

1 linha selecionada.


EDB360_6N                                                                       
-----------                                                                     
edb360_6n_                                                                      

1 linha selecionada.


EDB360_6O                                                                       
-----------                                                                     
edb360_6o_                                                                      

1 linha selecionada.


EDB360_7A                                                                       
-----------                                                                     
edb360_7a_                                                                      

1 linha selecionada.


EDB360_7B                                                                       
-----------                                                                     
edb360_7b_                                                                      

1 linha selecionada.


EDB360_7C                                                                       
-----------                                                                     
edb360_7c_                                                                      

1 linha selecionada.


EDB360_5W                                                                       
-----------                                                                     
edb360_5w_                                                                      

1 linha selecionada.


EDB360_PREFIX                                                                   
------------------------------------------------------------------------        
edb360                                                                          

1 linha selecionada.

antigo   1: SELECT LPAD(MOD(&&edb360_dbid.,1e6),6,'6') edb360_dbmod FROM DUAL
novo   1: SELECT LPAD(MOD(604135990,1e6),6,'6') edb360_dbmod FROM DUAL

EDB360                                                                          
------                                                                          
135990                                                                          

1 linha selecionada.

antigo   1: SELECT TO_CHAR(instance_number) connect_instance_number FROM &&v_object_prefix.instance
novo   1: SELECT TO_CHAR(instance_number) connect_instance_number FROM v$instance

CONNECT_INSTANCE_NUMBER                                                         
----------------------------------------                                        
1                                                                               

1 linha selecionada.


DATABASE_N                                                                      
----------                                                                      
db340                                                                           

1 linha selecionada.

antigo   1: SELECT SUBSTR('&&database_name_short.', 1, INSTR('&&database_name_short..', '.') - 1) database_name_short FROM DUAL
novo   1: SELECT SUBSTR('db340', 1, INSTR('db340.', '.') - 1) database_name_short FROM DUAL

DATABASE_N                                                                      
----------                                                                      
db340                                                                           

1 linha selecionada.

antigo   1: SELECT TRANSLATE('&&database_name_short.',
novo   1: SELECT TRANSLATE('db340',

DATABASE_N                                                                      
----------                                                                      
db340                                                                           

1 linha selecionada.


HOST_NAME_SHORT                                                                 
------------------------------                                                  
db340                                                                           

1 linha selecionada.

antigo   1: SELECT SUBSTR('&&host_name_short.', 1, INSTR('&&host_name_short..', '.') - 1) host_name_short FROM DUAL
novo   1: SELECT SUBSTR('db340', 1, INSTR('db340.', '.') - 1) host_name_short FROM DUAL

HOST_NAME_SHORT                                                                 
------------------------------                                                  
db340                                                                           

1 linha selecionada.

antigo   1: SELECT TRANSLATE('&&host_name_short.',
novo   1: SELECT TRANSLATE('db340',

HOST_NAME_SHORT                                                                 
------------------------------                                                  
db340                                                                           

1 linha selecionada.

antigo   1: SELECT SUBSTR(SYS_CONTEXT('USERENV','HOST'), 1 + INSTR(SYS_CONTEXT('USERENV','HOST'), '&&edb360_host_name_separator.', '&&edb360_host_name_position.', '&&edb360_host_name_occurrence.'), 30) host_name_suffix FROM DUAL
novo   1: SELECT SUBSTR(SYS_CONTEXT('USERENV','HOST'), 1 + INSTR(SYS_CONTEXT('USERENV','HOST'), '', '', ''), 30) host_name_suffix FROM DUAL

HOST_NAME_SUFFIX                                                                
------------------------------                                                  
                                                                                

1 linha selecionada.


ESP_HOST_NAME_SHORT                                                             
------------------------------                                                  
db340                                                                           

1 linha selecionada.

antigo   1: SELECT SUBSTR('&&esp_host_name_short.', 1, INSTR('&&esp_host_name_short..', '.') - 1) esp_host_name_short FROM DUAL
novo   1: SELECT SUBSTR('db340', 1, INSTR('db340.', '.') - 1) esp_host_name_short FROM DUAL

ESP_HOST_NAME_SHORT                                                             
------------------------------                                                  
db340                                                                           

1 linha selecionada.

antigo   1: SELECT TRANSLATE('&&esp_host_name_short.',
novo   1: SELECT TRANSLATE('db340',

ESP_HOST_NAME_SHORT                                                             
------------------------------                                                  
db340                                                                           

1 linha selecionada.


HOST_H                                                                          
------                                                                          
269584                                                                          

1 linha selecionada.


ESP_COLL                                                                        
--------                                                                        
20241003                                                                        

1 linha selecionada.


MIN_WAIT_TIME_MILLI MAX_WAIT_TIME_MILLI                                         
------------------- -------------------                                         
         ,000097656            16777216                                         

1 linha selecionada.


EDB360_FILE_TIME                                                                
--------------------                                                            
20241003_0929                                                                   

1 linha selecionada.

antigo   1: SELECT '&&common_edb360_prefix.'||(CASE '&&edb360_conf_incl_dbname_file.' WHEN 'Y' THEN '_&&database_name_short.' ELSE '_&&host_hash.' END) edb360_main_filename FROM DUAL
novo   1: SELECT 'edb360_135990'||(CASE 'N' WHEN 'Y' THEN '_db340' ELSE '_269584' END) edb360_main_filename FROM DUAL

EDB360_MAIN_FILENAME                                                            
--------------------                                                            
edb360_135990_269584                                                            

1 linha selecionada.

antigo   1: SELECT '&&edb360_output_directory.&&edb360_main_filename._&&edb360_file_time.' edb360_zip_filename FROM DUAL
novo   1: SELECT 'edb360_135990_269584_20241003_0929' edb360_zip_filename FROM DUAL

EDB360_ZIP_FILENAME                                                             
----------------------------------                                              
edb360_135990_269584_20241003_0929                                              

1 linha selecionada.




Sess�o alterada.


Sess�o alterada.

ALTER SESSION SET "_px_cdb_view_enabled" = FALSE
                  *
ERRO na linha 1:
ORA-02248: op��o inv�lida para ALTER SESSION 



Sess�o alterada.

antigo   1: ALTER SESSION SET NLS_DATE_FORMAT = '&&edb360_date_format.'
novo   1: ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD"T"HH24:MI:SS'

Sess�o alterada.

antigo   1: ALTER SESSION SET NLS_TIMESTAMP_FORMAT = '&&edb360_timestamp_format.'
novo   1: ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD"T"HH24:MI:SS.FF'

Sess�o alterada.

antigo   1: ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT = '&&edb360_timestamp_tz_format.'
novo   1: ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT = 'YYYY-MM-DD"T"HH24:MI:SS.FFTZH:TZM'

Sess�o alterada.


Sess�o alterada.


Sess�o alterada.

antigo   1: SELECT TRIM('.' FROM TRIM('0' FROM version)) db_vers_ofe FROM &&v_object_prefix.instance
novo   1: SELECT TRIM('.' FROM TRIM('0' FROM version)) db_vers_ofe FROM v$instance

DB_VERS_OFE                                                                     
-----------------                                                               
11.2.0.4                                                                        

1 linha selecionada.

antigo   1: ALTER SESSION SET optimizer_features_enable = '&&db_vers_ofe.'
novo   1: ALTER SESSION SET optimizer_features_enable = '11.2.0.4'

Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.

ALTER SESSION SET "_optimizer_aggr_groupby_elim" = FALSE
                  *
ERRO na linha 1:
ORA-02248: op��o inv�lida para ALTER SESSION 



Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.


Sess�o alterada.

ALTER SESSION SET "_optimizer_dsdir_usage_control"=0
                  *
ERRO na linha 1:
ORA-02248: op��o inv�lida para ALTER SESSION 


ALTER SESSION SET "_sql_plan_directive_mgmt_control" = 0
                  *
ERRO na linha 1:
ORA-02248: op��o inv�lida para ALTER SESSION 



Sess�o alterada.


Sess�o alterada.

antigo   1: ALTER SESSION SET TRACEFILE_IDENTIFIER = "&&edb360_tracefile_identifier."
novo   1: ALTER SESSION SET TRACEFILE_IDENTIFIER = "edb360_135990"

Sess�o alterada.

antigo   2:   IF TO_NUMBER('&&sql_trace_level.') > 0 THEN
novo   2:   IF TO_NUMBER('1') > 0 THEN
antigo   3:     EXECUTE IMMEDIATE 'ALTER SESSION SET EVENTS ''10046 TRACE NAME CONTEXT FOREVER, LEVEL &&sql_trace_level.''';
novo   3:     EXECUTE IMMEDIATE 'ALTER SESSION SET EVENTS ''10046 TRACE NAME CONTEXT FOREVER, LEVEL 1''';

Procedimento PL/SQL conclu�do com sucesso.


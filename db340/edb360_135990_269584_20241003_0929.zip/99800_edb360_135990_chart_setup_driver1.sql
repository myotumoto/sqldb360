antigo   3:   l_instances varchar2(15):='&&inst1_present.&&inst2_present.&&inst3_present.&&inst4_present.&&inst5_present.&&inst6_present.&&inst7_present.&&inst8_present.';
novo   3:   l_instances varchar2(15):='';
COL inst_01 HEA 'Inst 1' FOR 999990.000 PRI;                                    
DEF tit_01 = 'Inst 1';                                                          
COL inst_02 HEA 'Inst 2' FOR 999990.000 PRI;                                    
DEF tit_02 = 'Inst 2';                                                          
COL inst_03 HEA 'Inst 3' FOR 999990.000 PRI;                                    
DEF tit_03 = 'Inst 3';                                                          
COL inst_04 HEA 'Inst 4' FOR 999990.000 PRI;                                    
DEF tit_04 = 'Inst 4';                                                          
COL inst_05 HEA 'Inst 5' FOR 999990.000 PRI;                                    
DEF tit_05 = 'Inst 5';                                                          
COL inst_06 HEA 'Inst 6' FOR 999990.000 PRI;                                    
DEF tit_06 = 'Inst 6';                                                          
COL inst_07 HEA 'Inst 7' FOR 999990.000 PRI;                                    
DEF tit_07 = 'Inst 7';                                                          
COL inst_08 HEA 'Inst 8' FOR 999990.000 PRI;                                    
DEF tit_08 = 'Inst 8';                                                          
COL inst_09 NOPRI;                                                              
DEF tit_09 = '';                                                                
COL inst_10 NOPRI;                                                              
DEF tit_10 = '';                                                                
COL inst_11 NOPRI;                                                              
DEF tit_11 = '';                                                                
COL inst_12 NOPRI;                                                              
DEF tit_12 = '';                                                                
COL inst_13 NOPRI;                                                              
DEF tit_13 = '';                                                                
COL inst_14 NOPRI;                                                              
DEF tit_14 = '';                                                                
COL inst_15 NOPRI;                                                              
DEF tit_15 = '';                                                                

Procedimento PL/SQL conclu�do com sucesso.


1. Unzip sqld360_335833_5rurx5xtjwcu2_523132_20250305_1821.zip into a directory
2. Review 00001_sqld360_335833_5rurx5xtjwcu2_index.html

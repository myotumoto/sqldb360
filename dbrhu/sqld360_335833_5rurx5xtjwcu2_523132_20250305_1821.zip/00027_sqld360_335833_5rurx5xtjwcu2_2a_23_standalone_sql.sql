-- Standalone script to run the SQL, just copy and paste in SQL*Plus
-- or copy file 00027_sqld360_335833_5rurx5xtjwcu2_2a_23_standalone_sql.sql from sqld360_335833_5rurx5xtjwcu2_523132_20250305_1821.zip
VAR B1 VARCHAR2(32)


SELECT /*+ OPT_PARAM('_parallel_syspls_obey_force' 'false') */ KSPPCV.KSPPSTVL FROM X$KSPPCV KSPPCV, X$KSPPI KSPPI WHERE KSPPI.INDX = KSPPCV.INDX AND KSPPI.KSPPINM = :B1

/

-- List of binds from history
/*
--SNAP_ID: 15575 Elapsed Time: .001766 Executions: 10 Avg Elapsed Time: .000177
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15576 Elapsed Time: .002053 Executions: 12 Avg Elapsed Time: .000171
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15577 Elapsed Time: .001804 Executions: 10 Avg Elapsed Time: .00018
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15578 Elapsed Time: .001829 Executions: 10 Avg Elapsed Time: .000183
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15579 Elapsed Time: .002058 Executions: 10 Avg Elapsed Time: .000206
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15580 Elapsed Time: .002585 Executions: 12 Avg Elapsed Time: .000215
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15581 Elapsed Time: .001858 Executions: 10 Avg Elapsed Time: .000186
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15582 Elapsed Time: .001722 Executions: 10 Avg Elapsed Time: .000172
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15583 Elapsed Time: .001824 Executions: 10 Avg Elapsed Time: .000182
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15584 Elapsed Time: .001674 Executions: 10 Avg Elapsed Time: .000167
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15585 Elapsed Time: .001924 Executions: 10 Avg Elapsed Time: .000192
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15586 Elapsed Time: .002327 Executions: 12 Avg Elapsed Time: .000194
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15587 Elapsed Time: .001952 Executions: 10 Avg Elapsed Time: .000195
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15588 Elapsed Time: .001961 Executions: 10 Avg Elapsed Time: .000196
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15589 Elapsed Time: .001875 Executions: 10 Avg Elapsed Time: .000188
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15590 Elapsed Time: .001482 Executions: 8 Avg Elapsed Time: .000185
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15591 Elapsed Time: .002168 Executions: 12 Avg Elapsed Time: .000181
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15592 Elapsed Time: .001833 Executions: 10 Avg Elapsed Time: .000183
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15593 Elapsed Time: .016705 Executions: 16 Avg Elapsed Time: .001044
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15594 Elapsed Time: .017288 Executions: 15 Avg Elapsed Time: .001153
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15595 Elapsed Time: .018692 Executions: 15 Avg Elapsed Time: .001246
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15596 Elapsed Time: .018191 Executions: 15 Avg Elapsed Time: .001213
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15597 Elapsed Time: .015824 Executions: 15 Avg Elapsed Time: .001055
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15598 Elapsed Time: .018106 Executions: 17 Avg Elapsed Time: .001065
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15599 Elapsed Time: .019429 Executions: 9 Avg Elapsed Time: .002159
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15600 Elapsed Time: .015502 Executions: 5 Avg Elapsed Time: .0031
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15601 Elapsed Time: .015057 Executions: 5 Avg Elapsed Time: .003011
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15602 Elapsed Time: .01547 Executions: 5 Avg Elapsed Time: .003094
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15603 Elapsed Time: .014319 Executions: 5 Avg Elapsed Time: .002864
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15604 Elapsed Time: .02153 Executions: 5 Avg Elapsed Time: .004306
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15605 Elapsed Time: .018644 Executions: 6 Avg Elapsed Time: .003107
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15606 Elapsed Time: .014459 Executions: 5 Avg Elapsed Time: .002892
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15607 Elapsed Time: .015775 Executions: 5 Avg Elapsed Time: .003155
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15608 Elapsed Time: .015444 Executions: 5 Avg Elapsed Time: .003089
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15609 Elapsed Time: .017739 Executions: 5 Avg Elapsed Time: .003548
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15610 Elapsed Time: .018838 Executions: 5 Avg Elapsed Time: .003768
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15611 Elapsed Time: .022622 Executions: 6 Avg Elapsed Time: .00377
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15612 Elapsed Time: .018091 Executions: 5 Avg Elapsed Time: .003618
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15613 Elapsed Time: .018581 Executions: 5 Avg Elapsed Time: .003716
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15614 Elapsed Time: .016347 Executions: 5 Avg Elapsed Time: .003269
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15615 Elapsed Time: .019107 Executions: 5 Avg Elapsed Time: .003821
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15616 Elapsed Time: .022106 Executions: 6 Avg Elapsed Time: .003684
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15617 Elapsed Time: .002171 Executions: 12 Avg Elapsed Time: .000181
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15618 Elapsed Time: .001926 Executions: 10 Avg Elapsed Time: .000193
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15619 Elapsed Time: .001588 Executions: 10 Avg Elapsed Time: .000159
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15620 Elapsed Time: .002 Executions: 10 Avg Elapsed Time: .0002
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15621 Elapsed Time: .001396 Executions: 10 Avg Elapsed Time: .00014
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15622 Elapsed Time: .001389 Executions: 10 Avg Elapsed Time: .000139
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15623 Elapsed Time: .001483 Executions: 12 Avg Elapsed Time: .000124
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15624 Elapsed Time: .001313 Executions: 10 Avg Elapsed Time: .000131
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15625 Elapsed Time: .001178 Executions: 10 Avg Elapsed Time: .000118
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15626 Elapsed Time: .00126 Executions: 10 Avg Elapsed Time: .000126
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15627 Elapsed Time: .001373 Executions: 10 Avg Elapsed Time: .000137
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15628 Elapsed Time: .001671 Executions: 10 Avg Elapsed Time: .000167
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15629 Elapsed Time: .001677 Executions: 12 Avg Elapsed Time: .00014
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15630 Elapsed Time: .001346 Executions: 10 Avg Elapsed Time: .000135
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15631 Elapsed Time: .001234 Executions: 10 Avg Elapsed Time: .000123
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15632 Elapsed Time: .001328 Executions: 10 Avg Elapsed Time: .000133
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15633 Elapsed Time: .001372 Executions: 10 Avg Elapsed Time: .000137
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15634 Elapsed Time: .001556 Executions: 10 Avg Elapsed Time: .000156
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15635 Elapsed Time: .002015 Executions: 12 Avg Elapsed Time: .000168
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15675 Elapsed Time: .067497 Executions: 92 Avg Elapsed Time: .000734
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15676 Elapsed Time: .115327 Executions: 243 Avg Elapsed Time: .000475
EXEC :B1 := '_enable_Front_End_View_Optimization';
--SNAP_ID: 15677 Elapsed Time: .093424 Executions: 119 Avg Elapsed Time: .000785
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15678 Elapsed Time: .047387 Executions: 10 Avg Elapsed Time: .004739
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15679 Elapsed Time: .055623 Executions: 13 Avg Elapsed Time: .004279
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15680 Elapsed Time: .104872 Executions: 381 Avg Elapsed Time: .000275
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15681 Elapsed Time: .039294 Executions: 10 Avg Elapsed Time: .003929
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15682 Elapsed Time: .052518 Executions: 12 Avg Elapsed Time: .004377
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15683 Elapsed Time: .201446 Executions: 12 Avg Elapsed Time: .016787
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15684 Elapsed Time: .046506 Executions: 11 Avg Elapsed Time: .004228
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15685 Elapsed Time: .044116 Executions: 11 Avg Elapsed Time: .004011
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15686 Elapsed Time: .038615 Executions: 11 Avg Elapsed Time: .00351
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15687 Elapsed Time: .041273 Executions: 11 Avg Elapsed Time: .003752
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15688 Elapsed Time: .037034 Executions: 12 Avg Elapsed Time: .003086
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15689 Elapsed Time: .035657 Executions: 12 Avg Elapsed Time: .002971
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15690 Elapsed Time: .038513 Executions: 11 Avg Elapsed Time: .003501
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15691 Elapsed Time: .037287 Executions: 11 Avg Elapsed Time: .00339
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15692 Elapsed Time: .039818 Executions: 11 Avg Elapsed Time: .00362
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15693 Elapsed Time: .032091 Executions: 11 Avg Elapsed Time: .002917
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15694 Elapsed Time: .040078 Executions: 12 Avg Elapsed Time: .00334
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15695 Elapsed Time: .045946 Executions: 12 Avg Elapsed Time: .003829
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15696 Elapsed Time: .035809 Executions: 11 Avg Elapsed Time: .003255
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15697 Elapsed Time: .036918 Executions: 11 Avg Elapsed Time: .003356
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15698 Elapsed Time: .043448 Executions: 10 Avg Elapsed Time: .004345
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15699 Elapsed Time: .051921 Executions: 10 Avg Elapsed Time: .005192
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15700 Elapsed Time: .055359 Executions: 11 Avg Elapsed Time: .005033
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15701 Elapsed Time: .050311 Executions: 11 Avg Elapsed Time: .004574
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15702 Elapsed Time: .038329 Executions: 10 Avg Elapsed Time: .003833
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15703 Elapsed Time: .04287 Executions: 10 Avg Elapsed Time: .004287
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15704 Elapsed Time: .048387 Executions: 11 Avg Elapsed Time: .004399
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15705 Elapsed Time: .110407 Executions: 10 Avg Elapsed Time: .011041
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15706 Elapsed Time: .042064 Executions: 11 Avg Elapsed Time: .003824
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15707 Elapsed Time: .037806 Executions: 11 Avg Elapsed Time: .003437
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15708 Elapsed Time: .049402 Executions: 10 Avg Elapsed Time: .00494
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15709 Elapsed Time: .04694 Executions: 10 Avg Elapsed Time: .004694
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15710 Elapsed Time: .045526 Executions: 10 Avg Elapsed Time: .004553
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15711 Elapsed Time: .026057 Executions: 5 Avg Elapsed Time: .005211
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15712 Elapsed Time: .027138 Executions: 5 Avg Elapsed Time: .005428
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15738 Elapsed Time: .020746 Executions: 5 Avg Elapsed Time: .004149
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15739 Elapsed Time: .019929 Executions: 5 Avg Elapsed Time: .003986
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15740 Elapsed Time: .023819 Executions: 5 Avg Elapsed Time: .004764
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15741 Elapsed Time: .024155 Executions: 5 Avg Elapsed Time: .004831
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15742 Elapsed Time: .025326 Executions: 5 Avg Elapsed Time: .005065
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15743 Elapsed Time: .027233 Executions: 6 Avg Elapsed Time: .004539
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15744 Elapsed Time: .024052 Executions: 5 Avg Elapsed Time: .00481
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15745 Elapsed Time: .018111 Executions: 5 Avg Elapsed Time: .003622
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15746 Elapsed Time: .018192 Executions: 5 Avg Elapsed Time: .003638
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15747 Elapsed Time: .010661 Executions: 4 Avg Elapsed Time: .002665
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15748 Elapsed Time: .024939 Executions: 7 Avg Elapsed Time: .003563
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15749 Elapsed Time: .021249 Executions: 6 Avg Elapsed Time: .003542
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15750 Elapsed Time: .010672 Executions: 4 Avg Elapsed Time: .002668
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15751 Elapsed Time: .014419 Executions: 5 Avg Elapsed Time: .002884
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15752 Elapsed Time: .02479 Executions: 5 Avg Elapsed Time: .004958
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15753 Elapsed Time: .017317 Executions: 5 Avg Elapsed Time: .003463
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15754 Elapsed Time: .024533 Executions: 5 Avg Elapsed Time: .004907
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15755 Elapsed Time: .132989 Executions: 6 Avg Elapsed Time: .022165
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15756 Elapsed Time: .032922 Executions: 5 Avg Elapsed Time: .006584
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15757 Elapsed Time: .025002 Executions: 5 Avg Elapsed Time: .005
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15758 Elapsed Time: .024036 Executions: 5 Avg Elapsed Time: .004807
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15759 Elapsed Time: .022684 Executions: 5 Avg Elapsed Time: .004537
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15760 Elapsed Time: .017473 Executions: 5 Avg Elapsed Time: .003495
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15761 Elapsed Time: .013642 Executions: 4 Avg Elapsed Time: .003411
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15762 Elapsed Time: .027739 Executions: 5 Avg Elapsed Time: .005548
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15763 Elapsed Time: .026179 Executions: 5 Avg Elapsed Time: .005236
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15764 Elapsed Time: .024509 Executions: 5 Avg Elapsed Time: .004902
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15765 Elapsed Time: .022065 Executions: 5 Avg Elapsed Time: .004413
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15766 Elapsed Time: .020933 Executions: 5 Avg Elapsed Time: .004187
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15767 Elapsed Time: .031433 Executions: 6 Avg Elapsed Time: .005239
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15768 Elapsed Time: .021316 Executions: 5 Avg Elapsed Time: .004263
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15769 Elapsed Time: .023845 Executions: 5 Avg Elapsed Time: .004769
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15770 Elapsed Time: .024363 Executions: 5 Avg Elapsed Time: .004873
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15771 Elapsed Time: .019368 Executions: 5 Avg Elapsed Time: .003874
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15772 Elapsed Time: .033165 Executions: 5 Avg Elapsed Time: .006633
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15773 Elapsed Time: .031931 Executions: 6 Avg Elapsed Time: .005322
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15774 Elapsed Time: .01829 Executions: 5 Avg Elapsed Time: .003658
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15775 Elapsed Time: .018514 Executions: 5 Avg Elapsed Time: .003703
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15776 Elapsed Time: .019249 Executions: 5 Avg Elapsed Time: .00385
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15777 Elapsed Time: .016916 Executions: 5 Avg Elapsed Time: .003383
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15779 Elapsed Time: .008174 Executions: 9 Avg Elapsed Time: .000908
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15780 Elapsed Time: .001462 Executions: 10 Avg Elapsed Time: .000146
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15781 Elapsed Time: .001608 Executions: 10 Avg Elapsed Time: .000161
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15782 Elapsed Time: .001527 Executions: 10 Avg Elapsed Time: .000153
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15783 Elapsed Time: .001431 Executions: 10 Avg Elapsed Time: .000143
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15784 Elapsed Time: .001427 Executions: 10 Avg Elapsed Time: .000143
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15785 Elapsed Time: .001851 Executions: 12 Avg Elapsed Time: .000154
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15786 Elapsed Time: .001833 Executions: 10 Avg Elapsed Time: .000183
EXEC :B1 := '_qa_lrg_type';
--SNAP_ID: 15787 Elapsed Time: .001455 Executions: 10 Avg Elapsed Time: .000146
EXEC :B1 := '_qa_lrg_type';
*/
